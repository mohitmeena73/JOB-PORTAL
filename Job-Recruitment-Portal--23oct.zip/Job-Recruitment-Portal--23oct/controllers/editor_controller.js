module.exports.edit=function(req,res){
    res.end('<h1>Editor</h1>');
}